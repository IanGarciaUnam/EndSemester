package icc.exception;

public class NoFileException extends Exception{


  public NoFileException(){};

  public NoFileException(String s){
    super(s);
  }
}
