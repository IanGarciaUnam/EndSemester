Ian Israel García Vázquez
No. de Cuenta 317097364

Nota: Para agregar el metdo conversion que recibe como parametro el arreglo booleano, en la carpeta dia se encuentra como conversionBool.dia; ya que ocupo la sobrecarga de métodos.
