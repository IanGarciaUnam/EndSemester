
package icc;

/**
 *
 * @author Ian Israel Garcia Vazquez
 */

public class Prueba {

    public static void main(String[] s){

        System.out.println("Leyes de Morgan");
	System.out.println(" ¬(P && Q) == (¬P) || (¬Q)"); // Se muestra el letrero de las leyes de Demorgan - equivalencia conjuncion negada
	System.out.println(" ¬(P || Q) == (¬P) && (¬Q)"); // Se muestra el letrero de las leyes de Demorgan - equivalencia disyunción negada

	}
}
