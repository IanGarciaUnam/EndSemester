
package icc;

/**
 * 
 * @author Ian Israel García Vázquez
 */
public class Prueba {

    public static void main(String[] s){
        System.out.println("Conmutatividad:a + b = b + a "); // Muestra el primer letrero de Conmutatividad
	System.out.println("Asociatividad:(a + b) + c = a + ( b + c )");//Muestra el segundo letrero
	System.out.println("Neutro a + 0 = a");//Muestra el tercer letrero
	System.out.println("Inverso: a + ( - a ) = 0"); //Muestra el 4to Letrero
    }

}
