Ian Israel García Vázquez 
317097364


1. En el constructor de Scanner se utiliza System.in, ¿Que es System.in? ¿Que función
tiene?
System.in es un objeto llamado Input Stream, cuya función es la de permitir la entrada de datos a través del teclado o cualquiero otro dispositivo de entrada estandar, y este lee bytes.

2. En String ¿la función concat(String) modifica la cadena que guarda el objeto instanciado de String? Sí, concatena una String al final de la otra.


3. Exactamente ¿Que hace la funcion trim() de String?
ELimina caracteres blancos iniciales y finales de la cadena.

==========================================================================
				   NOTA
==========================================================================
1---------
String.format("%02d",int);

Permite darle el formato a nuestra variable en conversión, en este caso se le otorga un maximo de extensión de 2 caracteres para el entero. 

2--------
El test no funcionará de forma exitosa en algunos casos debido a lo anteriormente mencionado, donde el formato agrega ceros a las cifras menores a 10.


