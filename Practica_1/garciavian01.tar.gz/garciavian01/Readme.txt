IAN ISRAEL GARCÍA VÁZQUEZ 317097364 ICC

¿Qué es el código fuente? 
Es el conjunto de instrucciones redactadas por el programador en lenguaje de Alto nivel, que posteriormente se volverá de bajo nivel y se vuelven base del código objeto


¿Qué es el código objeto? Es aquel código que resulta tras la compilación de un código y este generalmente se encuentra en lenguaje máquina y  resulta generalmente incomprensible para nosotros.

¿Qué es código máquina? Son un conjunto de instrucciones ejecutables para la computadora, cuyo nivel se encuentra en 1 y 0

¿Qué son y para que sirven las pruebas unitarias? 
Es una prueba automatizada cuyo objetivo es verificar el funcionamiento de una unidad de código, siendo "la unidad", la parte más pequeña testeable de un código.
Cada una es independiente y no dependen de otra para realizar su tarea.


¿Cual es la diferencia entre System.out.println y System.out.print? El System.out.println realiza un salto de línea tras colocar cada cáracter del letrero especificado mientras que el System.out.print no salta de línea 



/***********************************NOTAS****************************/
Para resolver el Problema de Configuración Presentado en mi proceso de Testeo utilizé el siguiente código

$ sudo yum install ant-junit

Tras su ejecución solo volví a ejecutar el comando $ ant test
 y ahora funciona de forma adecuada.


Observé los errores cometidos, una sincera disculpa, no sabía que la carpeta de git quedaba oculta, a mi parecer ya la eliminé. 
Reitero mi  agradecimiento por permitirme volvera entregarla.

