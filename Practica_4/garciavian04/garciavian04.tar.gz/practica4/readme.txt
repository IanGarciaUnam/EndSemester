Ian Israel García Vázquez 
No. de CUenta 317097364
/******************************************************************************/
1.Semánticamente ¿Cuál es la diferencia entre for y while?
Ambas son estructuras cuya sintáctica se diferencia; en el for, debemos saber cuantos ciclos deseamos ejecutar, mientras que en while podemos ejecutarlo durante muchas ocasiones.
/******************************************************************************/
2¿Es necesaria la claúsula else para la correcta ejecución del if?
No, puesto que al colocar if, definimos lo que deseamos ocurra en el condicional(para determinada condición),
 mencionar lo que deseamos que ocurra cuando esta situación no ocurra 
dependerá del programador o necesidades del programa en cuestión.
/******************************************************************************/
3.¿Se pueden dejar sin inicializar los valores particulares dentro de un arreglo?
Sí, ya que al crear un arreglo, Java asigna valores por defecto a cada tipo 
de variable

