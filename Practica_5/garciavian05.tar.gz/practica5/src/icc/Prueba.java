
package icc;

import icc.interfaz.Interfaz;

public class Prueba{
    public static void main(String args[]){
        Interfaz f;
        f = new Interfaz();
        f.run();
    }
}
