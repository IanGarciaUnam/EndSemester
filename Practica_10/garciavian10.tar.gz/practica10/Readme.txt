Ian Israel García Vázquez 317097364

¿Cuál es el objetivo de usar genéricos en vez de Object?
Permiten al compilador informar de errores que hasta antes de su introducción
solo se podían lograr captar hasta la ejecución, igualmente permite eliminar los
cast simplificando y reduciendo la repetición de lineas de código que se
traducen el legibilidad.
