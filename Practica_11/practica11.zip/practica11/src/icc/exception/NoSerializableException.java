package icc.exception;

public class NoSerializableException extends Exception{

  public NoSerializableException(){};

    public NoSerializableException(String s){
      super(s);
    }

}
