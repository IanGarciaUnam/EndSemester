¿Porque se prefiere la recursión de cola a la recursión iterativa?
Es eficiente en el sentido de que no se corre el riesgo de desbordamiento que podría hacer fallar nuestro programa
¿Que efectos tiene la recursion ineficiente sobre el stack de ejecuciones de Java?
Vuelve un proceso sencilla en una operación lenta; puede hacer fallar un programa al desbordar la pila o inutilizar definitivamente una función.
