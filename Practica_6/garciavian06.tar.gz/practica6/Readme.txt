Ian Israel García Vázquez
No de Cuenta 317097364
1.¿Qué tipo puede ser el de variables utilizadas al paso por valor?
Primitivas(char, byte, short, int, long, float, double, boolean)
2.Cuando se pasa por parámetro una variable 
¿SIempre pasa que el valor de dicha variable cambia?
 No, depende si ha sido pasada por valor o por referencia
¿Porque?
Ya que en paso por valor, se crea una copia de la variable en la función que se implemente; mientras que en el paso por referencia, las modificaciones
que le realicemos a nuestra variable en la función afectarán a la variable original, directamente.

3.En programación ¿Qué significa refactorizar?
Reutilizar código con el fin de mejorar disminuir el tiempo de produciión del programa
y crear nuevas soluciones, solo donde es necesario.

Nota:
Lamento el retraso, pero descubrí un buen empleo para la recursión.
